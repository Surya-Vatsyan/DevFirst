﻿while(true){}
